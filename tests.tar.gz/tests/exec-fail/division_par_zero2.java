class Main {
    public static void main(String[] args) {
        int i = 1 % 0;
        System.out.print("hello world\n");
    }
}

