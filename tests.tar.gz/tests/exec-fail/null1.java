class A { String x; }
class Main {
    public static void main(String[] args) {
        A a = null;
        System.out.print(a.x);
    }
}

