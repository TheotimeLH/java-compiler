class Main {
    public static void main(String[] args) {

	if (! (false && 0 /0 == 1)) System.out.print("ok\n");
    }
}
