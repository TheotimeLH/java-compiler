/* ***dfghdfh"sdgsdgsd" # $% &

\n

f *** */

// essqai 123456!:ù:/*  sdkqsmdkqsmldkdqs "sdqsd \n dfsdf***

class Main {
    public static/**/void/* un commentaire est un séparateur valide */main(String[] args) {
	int x = 1/* Un seul commentaire,
		    le dernier "/" effectue une division *//1;
	if (x == 1 &&
	    "\n \" /* */ // qsdq#sds\n "
	    .equals("\n \" /* */ // qsdq#sds\n ") &&
	    "dfsdf/* dfsdf */ fsdf // sdfsdf "
	    .equals("dfsdf/* dfsdf */ fsdf // sdfsdf "))
	    /* / * // * / exit */
	    /* hello\n // */
	    System.out.print("ok\n");
    } // fin du main
} //
