
class Main {
  public static void main(String [ ] pour_changer) {
    int a = 0;
    int b = 1;
    while (a < 1000) {
      System.out.print(a + "\n");
      b = b + a;
      a = b - a;
    }
  }
}
