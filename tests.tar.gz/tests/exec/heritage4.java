class A extends Object {
    A () { System.out.print("ok\n"); }
}

class Main {
    public static void main(String[] args) { new A(); }
}
