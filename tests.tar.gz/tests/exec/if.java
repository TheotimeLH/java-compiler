class Main {
    public static void main(String[] args) {
	if (true)
	    if (false)
		;
	    else {
		if (1 == 2)
		    System.out.print("" + 0 / 0);
		else
		    System.out.print("ok\n");
	    }
    }
}
