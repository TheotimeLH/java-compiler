class Main {
    public static void main(String[] args) {
	boolean x;
        boolean y;
        boolean z;
	x = y = z = true;
	if (x && y && z)
	    System.out.print("ok\n");
    }
}
