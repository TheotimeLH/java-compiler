class Main {
    public static void main(String[] args) {
	int i = 42;
        if (true) {
            int j = 1;
        } else {
            int j = 2;
        }
        System.out.print(i + "\n");

    }
}

