class Main {
    public static void main(String[] args) {
	boolean b = true;
        if (b)
            System.out.print("true\n");
        else
            System.out.print("false\n");
        b = !b;
        if (b)
            System.out.print("true\n");
        else
            System.out.print("false\n");
    }
}

