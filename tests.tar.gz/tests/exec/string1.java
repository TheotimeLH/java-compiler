class Main {
    public static void main(String[] args) {
	String k = "k\n";
	System.out.print("o" + k);
    }
}
