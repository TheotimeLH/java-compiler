class A { void m() { int x = 0; x += 1; } }
class Main { public static void main(String[] args) { } }
