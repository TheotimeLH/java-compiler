class A { void m() { int x = new (,); } }
class Main { public static void main(String[] args) { } }
