class A { void m() { int x = 0 <== 0; } }
class Main { public static void main(String[] args) { } }
