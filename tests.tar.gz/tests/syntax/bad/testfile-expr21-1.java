class A {
    void m() { A i = (void) ; }
}
class Main { public static void main(String[] args) { } }
