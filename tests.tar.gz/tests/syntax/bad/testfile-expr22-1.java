class A {
    void m() { A i = j+ ; }
}
class Main { public static void main(String[] args) { } }
