class A { void m() { int x = new int; } }
class Main { public static void main(String[] args) { } }
