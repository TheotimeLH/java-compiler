class A {
    int i;j;
}
class Main { public static void main(String[] args) { } }
