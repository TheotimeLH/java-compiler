class A {
    j;
}
class Main { public static void main(String[] args) { } }
