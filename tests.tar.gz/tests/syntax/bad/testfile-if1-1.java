class A { void m() { if () ; } }
class Main { public static void main(String[] args) { } }
