class A { void m() { static int x = 0; } }
class Main { public static void main(String[] args) { } }
