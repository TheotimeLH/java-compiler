class A {
    void m() { int i = 1/// comment starts at first /, not second
        1; }
}
class Main { public static void main(String[] args) { } }
