class A {
    void m() { int i = 1/**/0; }
}
class Main { public static void main(String[] args) { } }
