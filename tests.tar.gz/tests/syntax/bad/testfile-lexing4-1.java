class A {
        void m() { i/**/nt i = 10; }
    }
class Main { public static void main(String[] args) { } }
