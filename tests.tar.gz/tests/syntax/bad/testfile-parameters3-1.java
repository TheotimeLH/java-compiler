class A { void m(x) {} }
class Main { public static void main(String[] args) { } }
