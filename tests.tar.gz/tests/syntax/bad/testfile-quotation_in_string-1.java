class A {
    void m() { String s = " " "; }
}
class Main { public static void main(String[] args) { } }
