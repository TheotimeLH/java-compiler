class A { int m() { return }
class Main { public static void main(String[] args) { } }
