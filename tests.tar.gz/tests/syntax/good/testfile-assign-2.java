
class M { boolean m() { return 1==2 && 3==4 || !(5>=6); } }
class Main { public static void main(String[] args) { } }
