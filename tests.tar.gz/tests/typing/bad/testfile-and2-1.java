class A { void m() { boolean x = true || null; } }
class Main { public static void main(String[] args) { } }
