
class A { A() { return this; } }
class Main { public static void main(String[] args) { } }
