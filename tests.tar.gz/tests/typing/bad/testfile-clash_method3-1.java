class A { void m(boolean x, int y) {} void m(boolean b, int n) {} }
class Main { public static void main(String[] args) { } }
