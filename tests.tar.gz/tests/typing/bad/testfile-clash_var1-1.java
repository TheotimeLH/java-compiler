class A { int x; int x; }
class Main { public static void main(String[] args) { } }
