class A { int x; boolean x; }
class Main { public static void main(String[] args) { } }
