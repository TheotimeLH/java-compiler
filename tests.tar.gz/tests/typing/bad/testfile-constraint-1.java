class A {}
class C {}
class D<X extends A> {}
class Test { void test(D<C> c) {} }
class Main { public static void main(String[] args) { } }
