
class A {}
class C {}
class D<X extends A> {}
class E extends D<C> {}
class Main { public static void main(String[] args) { } }
