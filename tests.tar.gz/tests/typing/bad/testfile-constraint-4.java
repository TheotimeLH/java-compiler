
class A {}
class C {}
class D<X extends A> {}
class E { D<C> d; }
class Main { public static void main(String[] args) { } }
