
class A {}
class C {}
class D<X extends A> {}
class E { D<C> m() {} }
class Main { public static void main(String[] args) { } }
