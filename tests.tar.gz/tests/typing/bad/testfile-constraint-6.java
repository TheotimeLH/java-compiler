
class A {}
class C {}
class D<X extends A> {}
class E { void m() { new D<C>(); } }
class Main { public static void main(String[] args) { } }
