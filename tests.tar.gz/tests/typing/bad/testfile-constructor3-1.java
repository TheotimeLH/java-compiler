class A {
    A(int x) { }

    void m() { A a = new A(true); }
}
class Main { public static void main(String[] args) { } }
