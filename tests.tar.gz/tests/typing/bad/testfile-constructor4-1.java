class A {
    A(int x, int y) { }

    void m() { A a = new A(1); }
}
class Main { public static void main(String[] args) { } }
