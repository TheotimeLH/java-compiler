class A { void m() { { int i = 0; }; i = 1; } }
class Main { public static void main(String[] args) { } }
