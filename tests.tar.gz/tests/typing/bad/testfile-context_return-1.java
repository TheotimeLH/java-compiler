class A { void m() { return x; } }
class Main { public static void main(String[] args) { } }
