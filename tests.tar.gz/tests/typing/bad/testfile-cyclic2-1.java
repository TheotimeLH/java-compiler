class A extends B {}
class B extends A {}
class Main { public static void main(String[] args) { } }
