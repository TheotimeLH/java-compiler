class A extends B {}
class B extends C {}
class C extends D {}
class D extends A {}
class Main { public static void main(String[] args) { } }
