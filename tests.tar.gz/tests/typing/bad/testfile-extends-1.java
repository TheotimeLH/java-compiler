class A {}
class B {}

class F<X> {}
class G extends F<A> {}
class Test1 { void test1(G g) { F<B> f = g; } }
class Main { public static void main(String[] args) { } }
