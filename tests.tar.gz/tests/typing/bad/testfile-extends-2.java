
interface I {}
class A extends I {}
class Main { public static void main(String[] args) { } }
