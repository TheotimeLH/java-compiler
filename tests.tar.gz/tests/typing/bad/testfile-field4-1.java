class A { boolean x; A() {} }
class B { int x; void m() { int y = new A().x; } }
class Main { public static void main(String[] args) { } }
