
class C<X extends Y> {}
class Main { public static void main(String[] args) { } }
