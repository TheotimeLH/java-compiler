
class A<X, Y> {}
class B extends A<Object> {}
class Main { public static void main(String[] args) { } }
