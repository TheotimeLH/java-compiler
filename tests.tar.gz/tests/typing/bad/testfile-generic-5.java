
class A<X, Y> {}
class B { void m(A<Object> a) {} }
class Main { public static void main(String[] args) { } }
