
class A<X> { }
class B extends A<X> {}
class Main { public static void main(String[] args) { } }
