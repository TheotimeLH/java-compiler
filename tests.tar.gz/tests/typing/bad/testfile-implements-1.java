class A implements I {}
class Main { public static void main(String[] args) { } }
