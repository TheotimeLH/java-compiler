
interface I { int m(); }
class C implements I { boolean m() { return true; } }

class Main { public static void main(String[] args) { } }
