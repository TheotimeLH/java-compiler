
interface I<X, Y> {}
class C implements I<Object> {}
class Main { public static void main(String[] args) { } }
