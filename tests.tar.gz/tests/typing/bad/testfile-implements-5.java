
class A {}
class B implements A {}
class Main { public static void main(String[] args) { } }
