
class B<X> implements X {}
class Main { public static void main(String[] args) { } }
