interface I {}
interface I {}
class Main { public static void main(String[] args) { } }
