
interface I { int m(); }
interface J { boolean m(); }
interface K extends I, J {  }
class Main { public static void main(String[] args) { } }
