
interface I extends J {}
interface J extends I {}
class Main { public static void main(String[] args) { } }
