
class A {}
interface I<X> extends J {}
interface J extends I<A> {}
class Main { public static void main(String[] args) { } }
