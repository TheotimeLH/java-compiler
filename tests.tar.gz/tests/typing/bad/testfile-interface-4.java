
interface I {}
class C { void m() { new I(); } }
class Main { public static void main(String[] args) { } }
