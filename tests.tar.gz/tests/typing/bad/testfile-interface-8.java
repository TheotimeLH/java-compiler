
interface I { void m(); }
interface J extends I { boolean m(); }
class Main { public static void main(String[] args) { } }
