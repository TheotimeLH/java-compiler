class A { void m() { int b = 1 < 1; } }
class Main { public static void main(String[] args) { } }
