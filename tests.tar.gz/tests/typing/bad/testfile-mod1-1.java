class A { void m() { int x = true % 1; } }
class Main { public static void main(String[] args) { } }
