class A {
    int f() {
	if (false)
	    return 0;
    }
}
class Main { public static void main(String[] args) { } }
