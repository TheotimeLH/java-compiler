class A {
    int f() {
	while(false)
	    return 0;
    }
}
class Main { public static void main(String[] args) { } }
