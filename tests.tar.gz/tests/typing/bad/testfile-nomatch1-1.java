
class A {
    void f() { int x = m(1); }
    void m() {}
}
class Main { public static void main(String[] args) { } }
