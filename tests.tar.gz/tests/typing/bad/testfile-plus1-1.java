class A { void m() { int x = 1 + true; } }
class Main { public static void main(String[] args) { } }
