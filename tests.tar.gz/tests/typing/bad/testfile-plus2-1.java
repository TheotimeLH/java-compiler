class A { void m() { int x = 1 - null; } }
class Main { public static void main(String[] args) { } }
