class A {
    int m(B b) { return 0; }
}
class B extends A {
    void m(B b) {}
}
class Main { public static void main(String[] args) { } }
