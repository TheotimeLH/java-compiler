class A { B b; }
class Main { public static void main(String[] args) { } }
