class A { boolean m(int x) { return x; } }

class Main { public static void main(String[] args) { } }
