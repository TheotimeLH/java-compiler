class A {
    boolean b;
    A(int x) { b = x; }
}

class Main { public static void main(String[] args) { } }
