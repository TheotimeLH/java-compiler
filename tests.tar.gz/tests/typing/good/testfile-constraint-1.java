class A {}
class D<X extends A> {}
class Test { void test(D<A> c) {} }
class Main { public static void main(String[] args) { } }
