
class A {}
class B extends A {}
class D<X extends A> {}
class Test { void test(D<B> c) {} }
class Main { public static void main(String[] args) { } }
