
class A<X extends A<B>> {}
class B extends A<B> {}
class Main { public static void main(String[] args) { } }
