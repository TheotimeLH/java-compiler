
class A<X> { }
class B extends A<C> {}
class C {}
class Main { public static void main(String[] args) { } }
