
class C<T> { void m(C<T> c) { } }
class Main { public static void main(String[] args) { } }
