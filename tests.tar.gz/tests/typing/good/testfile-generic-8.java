
class C<T> { void m() { C<T> l = null; } }
class Main { public static void main(String[] args) { } }
