class A { void m() { new Object(); } }
class Main { public static void main(String[] args) { } }
