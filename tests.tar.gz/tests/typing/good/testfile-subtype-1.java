class A {}
class B extends A { B(){} }
class M { void m() { A a = new B(); } }
class Main { public static void main(String[] args) { } }
