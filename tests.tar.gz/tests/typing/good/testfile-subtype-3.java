
class A {}
class B extends A { A m(B b) { return b; } }
class Main { public static void main(String[] args) { } }
